﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsDownloader
{
    public partial class Form2 : Form
    {
        private string url,filename;
        public string DlUrl
        {
            get { return url; }
            set { url = value; }
        }

        public string FileName
        {
            get { return filename; }
            set { filename = value; }
        }
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                url = textBox1.Text;
                filename = textBox2.Text;
                this.DialogResult = DialogResult.Ignore;
                Close();
            }
            else
            {
                MessageBox.Show("填完表格再吵！", "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "所有文件(*.*)|*.*";
            sfd.Title = "下载到";
            sfd.AutoUpgradeEnabled = true;
            if (sfd.ShowDialog() == DialogResult.OK && sfd.FileName != "")
            {
                textBox2.Text = sfd.FileName;
            }
        }
    }
}
