﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsDownloader
{
    public partial class Form1 : Form
    {
        private bool stopnow = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void DownloadFile(string URL, string filename, ProgressBar prog, Label label1)
        {
            button1.Text = "取消下载";
            float percent = 0;
            try
            {
                System.Net.HttpWebRequest Myrq = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URL);
                System.Net.HttpWebResponse myrp = (System.Net.HttpWebResponse)Myrq.GetResponse();
                long totalBytes = myrp.ContentLength;
                if (prog != null)
                {
                    prog.Maximum = (int)totalBytes;
                }
                System.IO.Stream st = myrp.GetResponseStream();
                System.IO.Stream so = new System.IO.FileStream(filename, System.IO.FileMode.Create);
                long totalDownloadedByte = 0;
                byte[] by = new byte[1024];
                int osize = st.Read(by, 0, (int)by.Length);
                while (osize > 0)
                {
                    if (stopnow == true)
                    {
                        so.Close();
                        st.Close();
                        label1.Text = "已取消";
                        prog.Value = 0;
                        stopnow = false;
                        break;
                    }
                    totalDownloadedByte = osize + totalDownloadedByte;
                    Application.DoEvents();
                    so.Write(by, 0, osize);
                    if (prog != null)
                    {
                        prog.Value = (int)totalDownloadedByte;
                    }
                    osize = st.Read(by, 0, (int)by.Length);

                    percent = (float)totalDownloadedByte / (float)totalBytes * 100;
                    label1.Text = "当前下载进度" + percent.ToString() + "% (" + Math.Round(totalDownloadedByte / 1024d / 1024d) + "MB/" + Math.Round(totalBytes / 1024d / 1024d) + "MB)";
                    Application.DoEvents();
                }
                prog.Value = 0;
                label1.Text = "已完成";
                button1.Text = "新建下载";
                so.Close();
                st.Close();
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "新建下载")
            {
                Form2 form_newdl = new Form2();
                if (form_newdl.ShowDialog() == DialogResult.Ignore)
                {
                    try
                    {
                        DownloadFile(form_newdl.DlUrl, form_newdl.FileName, progressBar1, label2);
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                }
            }
            else
            {
                stopnow = true;
                button1.Text = "新建下载";
            }
        }
    }
}
