﻿using System;
using System.Windows.Forms;
using Microsoft.WindowsAPICodePack.Dialogs;
using Microsoft.WindowsAPICodePack.Taskbar;
using System.Security.Principal;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace WindowsFormsDownloader
{
    public partial class Form_Main : Form
    {
        TaskbarManager tm = TaskbarManager.Instance;
        private bool stopnow = false;
        public Form_Main()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            AddShieldToButton(button1);
        }

        public void DownloadFile(string URL, string filename, ProgressBar prog, Label label1)
        {
            button1.Text = "取消下载";
            float percent = 0;
            try
            {
                System.Net.HttpWebRequest Myrq = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URL);
                System.Net.HttpWebResponse myrp = (System.Net.HttpWebResponse)Myrq.GetResponse();
                long totalBytes = myrp.ContentLength;
                if (prog != null)
                {
                    prog.Maximum = (int)totalBytes;
                }
                System.IO.Stream st = myrp.GetResponseStream();
                System.IO.Stream so = new System.IO.FileStream(filename, System.IO.FileMode.Create);
                long totalDownloadedByte = 0;
                byte[] by = new byte[1024];
                int osize = st.Read(by, 0, (int)by.Length);
                tm.SetProgressState(TaskbarProgressBarState.Normal);
                while (osize > 0)
                {
                    if (stopnow == true)
                    {
                        so.Close();
                        st.Close();
                        label1.Text = "已取消";
                        prog.Value = 0;
                        stopnow = false;
                        st.Close();
                        so.Close();
                        System.IO.File.Delete(filename);
                        break;
                    }
                    totalDownloadedByte = osize + totalDownloadedByte;
                    Application.DoEvents();
                    so.Write(by, 0, osize);
                    if (prog != null)
                    {
                        prog.Value = (int)totalDownloadedByte;
                        tm.SetProgressValue(prog.Value, prog.Maximum);
                    }
                    osize = st.Read(by, 0, (int)by.Length);

                    percent = (float)totalDownloadedByte / (float)totalBytes * 100;
                    label1.Text = "当前下载进度" + Math.Round(percent, 2) + "% (" + Math.Round(totalDownloadedByte / 1024d / 1024d, 2) + "MB/" + Math.Round(totalBytes / 1024d / 1024d, 2) + "MB)";
                    Application.DoEvents();
                }
                prog.Value = 0;
                tm.SetProgressState(TaskbarProgressBarState.NoProgress);
                label1.Text = "已完成";
                button1.Text = "新建下载";
                so.Close();
                st.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //RestartElevated();
            if (button1.Text == "新建下载")
            {
                Form_New form_newdl = new Form_New();
                if (form_newdl.ShowDialog() == DialogResult.Ignore)
                {
                    try
                    {
                        DownloadFile(form_newdl.DlUrl, form_newdl.FileName, progressBar1, label2);
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                }
            }
            else
            {
                stopnow = true;
                button1.Text = "新建下载";
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (TaskDialog.IsPlatformSupported)
            {
                TaskDialog td = new TaskDialog();
                td.Text = "This is a good software.\nDo you love it?Give us marks to let us be better!";
                td.Caption = "Downloader";
                td.Icon = TaskDialogStandardIcon.Information;//icon_dlg;
                
                td.InstructionText = "Give us marks!";
                TaskDialogCommandLink tdcl1 = new TaskDialogCommandLink("tdcl1", "I love it!", "This is a good downloader,it's fast,easy and nice.");
                TaskDialogCommandLink tdcl2 = new TaskDialogCommandLink("tdcl2", "Not bad.", "The downloader is the same as other downloader like \"Xunlei\".");
                TaskDialogCommandLink tdcl3 = new TaskDialogCommandLink("tdcl3", "Shit for anyway!", "This is too bad.When it's loading,it's so card!");
                td.Controls.Add(tdcl1);
                td.Controls.Add(tdcl2);
                td.Controls.Add(tdcl3);
                td.ProgressBar = new TaskDialogProgressBar();
                td.ProgressBar.Maximum = 100;
                td.ProgressBar.Minimum = 0;
                td.ProgressBar.Value = 99;
                td.ProgressBar.State = TaskDialogProgressBarState.Paused;
                td.Show();
                
                linkLabel1.Visible = false;
            }
            else
            {
                System.Diagnostics.Process.Start("http://www.tranchbellic.cn");
            }
        }

        private void commandLink1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Fuck,I cannot find the file!","Error!",MessageBoxButtons.OK,MessageBoxIcon.Error);
        }

        static internal bool IsAdmin()
        {
            WindowsIdentity id = WindowsIdentity.GetCurrent();
            WindowsPrincipal p = new WindowsPrincipal(id);
            return p.IsInRole(WindowsBuiltInRole.Administrator);
        }

        static internal void AddShieldToButton(Button b)
        {
            b.FlatStyle = FlatStyle.System;
            SendMessage(b.Handle, BCM_SETSHIELD, 0, 0xFFFFFFFF);
        }

        [DllImport("user32")]
        public static extern UInt32 SendMessage
            (IntPtr hWnd, UInt32 msg, UInt32 wParam, UInt32 lParam);

        internal const int BCM_FIRST = 0x1600; //Normal button
        internal const int BCM_SETSHIELD = (BCM_FIRST + 0x000C); //Elevated button

        internal static void RestartElevated()
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.UseShellExecute = true;
            startInfo.WorkingDirectory = Application.StartupPath;
            startInfo.FileName = Form_New.GetFileName(Application.ExecutablePath);
            startInfo.Verb = "runas";
            try
            {
                Process p = Process.Start(startInfo);
            }
            catch (System.ComponentModel.Win32Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.Exit();
        }
    }
}
