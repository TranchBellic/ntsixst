﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsDownloader
{
    public partial class Form_New : Form
    {
        private string url,filename;
        public string DlUrl
        {
            get { return url; }
            set { url = value; }
        }

        public string FileName
        {
            get { return filename; }
            set { filename = value; }
        }
        public Form_New()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                url = textBox1.Text;
                filename = textBox2.Text;
                this.DialogResult = DialogResult.Ignore;
                Close();
            }
            else
            {
                MessageBox.Show("填完表格再吵！", "Error:", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            SaveFileDialog sfd = new SaveFileDialog();
            if (textBox1.Text != "")
            {
                sfd.FileName = GetFileName(textBox1.Text);
                sfd.Filter = GetFileExt(textBox1.Text) + "文件(*." + GetFileExt(textBox1.Text) + ")|*." + GetFileExt(textBox1.Text);
                sfd.AddExtension = true;
            }
            else
            {
            sfd.Filter = "所有文件(*.*)|*.*";
            }

            sfd.Title = "下载到";
            sfd.AutoUpgradeEnabled = true;
            if (sfd.ShowDialog() == DialogResult.OK && sfd.FileName != "")
            {
                textBox2.Text = sfd.FileName;
                textBox3.Text = GetFileName(sfd.FileName);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                textBox3.Text = GetFileName(textBox1.Text);
            }
        }


        static public string GetFileName(string path)
        {
            int index = path.LastIndexOf("?");
            string result = path;
            if (index > 0)
            {
                result = path.Substring(1, index - 1);
            }

            index = path.LastIndexOf("\\");

            if (index > 0)
            {
                result = path.Substring(index + 1, path.Length - index - 1);
                return result;
            }
            return null;
        }

        static public string GetFileExt(string path)
        {
            int index = path.LastIndexOf("?");
            string result = path;
            if (index > 0)
            {
                result = path.Substring(1, index - 1);
            }

            index = result.LastIndexOf(".");

            if (index > 0)
            {
                result = path.Substring(index + 1, path.Length - index - 1);
                return result;
            }
            return null;
        }
    }
}
